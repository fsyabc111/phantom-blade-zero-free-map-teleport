﻿影之刃零：地图自由传送（免穿行符）
FreeMapTeleport 1.0.1

适用版本
Steam App ID：4115450
已验证构建：26266538

功能
在普通地图选择已激活的铃铛，使用游戏原有的传送操作即可直接传送。
无需持有穿行符，不弹出消耗穿行符的确认框，不消耗穿行符。
保留战斗、空中、异常状态、剧情关键段、禁传区域、异空间和目的地区域限制。
不会解锁尚未激活的铃铛。

安装
1. 完整退出游戏，并自行备份存档。
2. 在 Steam 中右键游戏 → 管理 → 浏览本地文件。
3. 将本压缩包内的 ProjectPBZ 文件夹解压到游戏根目录。
   安装后下面三个文件应位于 ProjectPBZ/Content/Paks/：
   ProjectPBZ-FreeMapTeleport_999_P.pak
   ProjectPBZ-FreeMapTeleport_999_P.utoc
   ProjectPBZ-FreeMapTeleport_999_P.ucas
4. 三个文件必须一起保留。重启游戏后，在安全野外打开普通地图，选择已激活的铃铛传送。

卸载
退出游戏，仅删除以上三个 FreeMapTeleport 文件，然后重启游戏。

兼容性
本 Mod 替换 JavaScript/UI/Widget/Map.js，与替换同一脚本的地图 Mod 可能冲突。
目前只验证了 Steam Build 26266538。游戏更新后需要重新验证。

验证记录
17 项脚本行为检查、脚本语法、包内脚本回读和 IoStore 容器校验通过。
2026-10-30：确认修改脚本已在游戏进程中加载，用户实测普通地图直接传送成功。
跨区域传送与传送后读档尚未分别确认。

更新记录
1.0.1：补齐同名 IoStore 容器，修复只有 .pak 文件时游戏无法挂载的问题。

这是手动安装包，不是 Steam 创意工坊订阅项。
